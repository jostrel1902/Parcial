package co.edu.umanizales.manage_store.controller.dto;

import lombok.Data;

@Data
public class ErrorDTO {
    private int code;
    private String message;
}
