package co.edu.umanizales.manage_store;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManageStoreApplication {

    public static void main(String[] args) {
        SpringApplication.run(ManageStoreApplication.class, args);
    }

}
