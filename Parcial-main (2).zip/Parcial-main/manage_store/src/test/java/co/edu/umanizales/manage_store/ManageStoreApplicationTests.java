package co.edu.umanizales.manage_store;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManageStoreApplicationTests {

    @Test
    void contextLoads() {
    }

}
